class StMaker;
class StChain;
class StPicoDstMaker;
class StPicoDst;
class StPicoEvent;


StChain *chain;

void readPicoDst(TString InputFileList, TString OutputDir="test") 
{

  Int_t nFiles = 1e+4;

  // Load libraries
  gROOT->LoadMacro("$STAR/StRoot/StMuDSTMaker/COMMON/macros/loadSharedLibraries.C");
  loadSharedLibraries();

  gSystem->Load("StPicoEvent");
  gSystem->Load("StPicoDstMaker");
  gSystem->Load("StRefMultCorr");
  gSystem->Load("MyAnalysisMaker");
  //gSystem->Load("MyAnalysisMaker.so");
  
  // List of member links in the chain
  StChain*                    chain  =  new StChain ;
  StPicoDstMaker*          picoDstMaker  =  new StPicoDstMaker(2,InputFileList,"picoDst");
  MyAnalysisMaker*    AnalysisCode   =  new MyAnalysisMaker(picoDstMaker, OutputDir);
  

  if( chain->Init()==kStErr )
    { 
      cout<<"chain->Init();"<<endl;
      return;
    }
  
  cout << "I am hereeeeeeeeeee "<<endl;
    
  
  //for test mode
  Int_t nEvents =  100000000;
  //for full job 
  int total = picoDstMaker->chain()->GetEntries();
  cout << " Total entries = " << total << endl;
  if(nEvents>total) nEvents = total;
  
  nEvents = 5000;
  // Loop over the links in the chain
  
  for (Int_t i=0; i<nEvents; i++){

    if(i%1000==0)
      cout << "Working on eventNumber " << i << endl;
    
    chain->Clear();
    int iret = chain->Make(i);
    
    if (iret) { cout << "Bad return code!" << iret << endl; break;}

    total++;
  }
  
  
  chain -> Finish() ;
  

  // Cleanup
  delete AnalysisCode;
  delete picoDstMaker;
  delete chain ;

}

