#ifndef MyAnalysisMaker_def
#define MyAnalysisMaker_def

#include "StMaker.h"
#include "TString.h"
#include "TF1.h"
#include "TH1.h"
#include "TH2F.h"
#include "TH3F.h"
#include "TVector2.h"
#include "TVector3.h"
#include "TProfile.h"
#include "TLorentzVector.h"


class StPicoEvent;
class StPicoDst;
class StPicoDstMaker;
class StPicoTrack;
class StRefMultCorr ;
class TF1         ;
class TFile         ;
class TH1F          ;
class TH2F          ;
class TH3F          ;
class TString       ;
class TVector2      ;
class TVector3      ;
class TProfile      ;
class TProfile2D    ;
class TLorentzVector;
class StEpdEpFinder;  



#define MaxNumberOfCentrality		9
#define MaxNumberOfnharmo		2
#define MaxNumberOfCorrection		15	

#include <string>

//define in header
#if !defined(ST_NO_NAMESPACES)
using namespace std;
#endif

class MyAnalysisMaker : public StMaker
{
 public:
  MyAnalysisMaker(StPicoDstMaker *picoMaker, TString fOutDir="");            //  Constructor
  virtual          ~MyAnalysisMaker( ) ;           //  Destructor

  Int_t Init    ( ) ;                              //  Initiliaze the analysis tools ... done once
  Int_t Make    ( ) ;                              //  The main analysis that is done on each event
  Int_t Finish  ( ) ;                              //  Finish the analysis, close files, and clean up.

  Int_t  nTofMatchedTracks();
  Double_t calcCosThetaStar(TLorentzVector ax, TLorentzVector ay, TLorentzVector aphi);
  Bool_t IsBadEvent(StPicoEvent *picoEvent);
  //Bool_t IsBadTrack(StMuTrack * track);
  Int_t EventCentrality(unsigned short muMult);
  void SetOutputFileName(TString name) 
  {OutputFileName = name;}                     // Make name available to member functions
  

  double dDipAngle(TLorentzVector a,TLorentzVector b);
  double OpenAngle(TLorentzVector a,TLorentzVector b, double fres_mass);
  
    
 private:
  StPicoDstMaker *mPicoDstMaker;
  StPicoEvent    *picoEvent;
  StPicoDst      *mPicoDst;
  StRefMultCorr* refmultCorrUtil;
  TFile*        histogram_output;                   //  Histograms outputfile pointer
    
  UInt_t        mEventsProcessed;                   //  Number of Events read and processed
  TString         OutputFileName;                   //  Name of the histogram output file 
  Double_t                 Qxsum;
  Double_t                 Qysum;
  Double_t            VertexZPos;

  double vx;
  double vy;
  double vz;
    
  // Double_t              reweight;
  //  Double_t                weight;
  Double_t              zdc_cons;
  Double_t              bbc_cons;
  // Float_t                     Pi;
  //Float_t                  twoPi;
  Float_t               VpdVzPos;
  Int_t                     cent;   
  Int_t                  trigger;
  Int_t                cent_flag;
  Int_t                runnumber;
  Int_t               ChargeFlag;
  Int_t           runnumber_flag;
  Int_t         runnumberPointer;
  // Int_t  CurrentEvent_centrality; 
  Char_t                name[60];
  Char_t               title[60];
  //-----------------------------


 

 //------QA histograms pointer------------
 TH1F                      *EventCount;
 TH1F                       *CentCount;
 TH1F                      *EventPlane;
 TH1F                         *VertexZ;
 TH1F                          *Vpd_vZ;
 TH2F                        *VertexXY;
 TH2F                           *hQxQy;
 TH1F                         *RefMult;
 TH1F                       *CentCount_Vz;
 TH2F *h2Refm_Tofm;
 
 TH2F *betaHis ;
 TH2F *hMass2 ;
 TH2F *hMass2_cut_pion ;
 TH2F *hMass2_cut_kaon ;
 TH2F *dEdxvspkaon;
 TH2F *dEdxvsppion;
 TH2F *dEdxvsp;

 //TProfile *pv1full_Pion_Rap;
 //TProfile *pv1full_Kaon_Rap;
 
 

 float day_num;

 
 //Strong decay resonances:
 TH3F *syst_phimeson_NumTPC;
 TH3F *syst_phimeson_RotTPC;  
 
 struct trackk__{
   Double_t s_qq;
   TVector3 s_mom;
   Double_t s_dca;
   Double_t s_nsigma_pion;
   Double_t s_nsigma_kaon;
   Double_t s_nhitsfit;
   Double_t s_hitsratio;
 };
 
 typedef std::vector<trackk__> vect_trackk__;
 
 vect_trackk__ mPosProton;
 vect_trackk__ mNegProton;
 vect_trackk__ mPosPion;
 vect_trackk__ mNegPion;
 vect_trackk__ mPosKaon;
 vect_trackk__ mNegKaon;

 void MakeRealPair_Rsn();
 void MakeRealRotPair_Rsn();
 void   clearPIDTracks_Rsn();
 
 
 double PI;
 double twoPI;  
 float piMass ;
 float kMass ;
 float prMass ;
 float phiMass ;
 float deltaMass ;
 float kstarMass ;
 int iran ;
 int iran_sub;
 float Pi ;
 float twoPi ;
 bool oddeven;
 float weight;
 float CurrentEvent_Psi;
 int CurrentEvent_centrality; 
 float CurrentEvent_vz;
 float CurrentEvent_vy;
 float CurrentEvent_vx;
 double reweight;

 //for BBC
 float CurrentEvent_resolutionBBC;

 //for EPD
 float CurrentEvent_resolutionEPD;
 
 float CurrentEvent_Psi_Rndm;
 
 double tempArray[30][2000];



 TString mFileNameBase;

  //------------end for phi--------------
 protected:

 ClassDef(MyAnalysisMaker,1)                       //Macro for CINT compatability
    
};

#endif















