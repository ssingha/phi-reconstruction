#include "MyAnalysisMaker.h"
#include <iostream>

#include "StRoot/StPicoEvent/StPicoEvent.h"
#include "StRoot/StPicoEvent/StPicoDst.h"
#include "StRoot/StPicoDstMaker/StPicoDstMaker.h"
#include "StRoot/StPicoEvent/StPicoTrack.h"
#include "StRoot/StPicoEvent/StPicoBTofPidTraits.h"
#include "StRoot/StPicoEvent/StPicoBbcHit.h"

#include "StRoot/StRefMultCorr/StRefMultCorr.h"
#include "StRoot/StRefMultCorr/CentralityMaker.h"

#include "TF1.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TH3F.h"
#include "TFile.h"
#include "TMath.h"
#include "TRandom.h"
#include "TRandom3.h"
#include "TProfile.h"
#include "TVector2.h"
#include "TVector3.h"
#include "TProfile2D.h"
#include "TProfile.h"
#include "TLorentzVector.h"
#include "StThreeVectorF.hh"
#include "TObjArray.h"
#include "TComplex.h"





//run numbers
#include "run_200.h"//run-11


const float fRapcut_pair = 1.0;


using namespace std;

ClassImp(MyAnalysisMaker)                       // Macro for CINT compatibility
MyAnalysisMaker::MyAnalysisMaker(StPicoDstMaker *picoMaker, TString fOutDir) : StMaker("MyAnalysisMaker")
{                                               // Initialize data members here.
  mPicoDstMaker      = picoMaker ;                    // Pass MuDst pointer to DstAnlysisMaker Class member functions
  mPicoDst = 0;
  histogram_output = NULL  ;                    // Zero the Pointer to histogram output file
  mEventsProcessed = 0     ;                    // Zero the Number of Events processed by the maker 
  mFileNameBase = fOutDir;
  //OutputFileName = "" ;                         // Output File Name( will be set inside the "readMuDst".C )
}


MyAnalysisMaker::~MyAnalysisMaker() 
{/* */}


Int_t MyAnalysisMaker::Init()
{ 
//change here:

  runnumber_flag   = 1299      ;      //for UU
  //runnumber_flag   = 804      ;      //for UU

//----------------------------------------
 runnumber        = -13100001;  //just a no.
 runnumberPointer =         0;
 cent_flag        =        10;
 Pi               =   3.14159;
 twoPi            =   6.28318;


//-----------------------------------------------------------------------------------------
 //histogram_output = new TFile(OutputFileName,"RECREATE") ;  //

 histogram_output = new TFile(Form("%s.root", mFileNameBase.Data()),"RECREATE") ; 
 
 refmultCorrUtil  = new StRefMultCorr();
 
 //QA histograms:
 EventCount       = new TH1F("EventCount","EventCount",10,  0, 10);  //1
 CentCount        = new TH1F("CentCount", " CentCount",10,  0, 10);  //2
 VertexZ          = new TH1F("VertexZ", "  VertexZ ", 1000,-100.,100.); //3
 Vpd_vZ           = new TH1F("Vpd_vZ", "    VPD Vz ", 500,-50.,50.); //3
 RefMult          = new TH1F("RefMult", " RefMult ", 2000,0,  2000);  //4
 VertexXY         = new TH2F("VertexXY","VertexXY", 200,-10.,10.,200,-10.,10.);//9
 CentCount_Vz        = new TH1F("CentCount_Vz", " CentCount Vz cut",10,  0, 10);  //2
 h2Refm_Tofm = new TH2F("h2Refm_Tofm", "h2Refm_Tofm", 500, 0, 500, 500, 0, 500);
 
 dEdxvsp = new TH2F("dEdxvsp","dedx vs p",1000,-5.,5.,500,0.,30);
 dEdxvspkaon = new TH2F("dEdxvspkaon","dedx vs p of kaon ",1000,-5.,5.,500,0.,30);
 betaHis = new TH2F("betaHis","1/beta vs p",600,0,3,800,0.5,3.5);
 hMass2 = new TH2F("masssHis","Mass2 vs p",500,0,5,500,-0.5,1.5);
 hMass2_cut_kaon = new TH2F("masssHis_cut_kaon","Mass2 vs p after cut",500,0,5,500,-0.5,1.5);
 
 
 
 //---------------------------------define histogram for phi analysis---------------------------------------------------------------------------------------------- 
 //3D histogram with X: invariant mass, Y: pT, Z: centrality
 
 //Same event
 syst_phimeson_NumTPC = new TH3F("syst_phimeson_NumTPC", "syst_phimeson_NumTPC", 120,0.98,1.10, 100, 0, 10, 10, 0, 10);
 
 //Rotated event
 syst_phimeson_RotTPC = new TH3F("syst_phimeson_RotTPC", "syst_phimeson_RotTPC", 120,0.98,1.10, 100, 0, 10, 10, 0, 10);
 
 
 //--------------------
 
 //define variable for phi meson
 PI=3.1415926;
 twoPI=6.2831854;
 piMass = 0.13957;//pion
 kMass = 0.49368;
 prMass = 0.939;//pion
 phiMass = 1.01946;
 iran = 0;
 iran_sub = 0;
 Pi = 3.14159;
 twoPi = 6.28318;
 //CurrentEvent_nKaons = 0;
 //CurrentEvent_nPions = 0;
 CurrentEvent_vz = 999.;
 CurrentEvent_vx = 999.;
 CurrentEvent_vy = 999.;
 vx = 999;
 vy = 999;
 vz = 999;
 weight = 1.;
 VertexZPos = -100.0;
 VpdVzPos   = -100.0;
 
 
 refmultCorrUtil  = new StRefMultCorr();
 
 //for Run-14 200 GeV
 //refmultCorrUtil = new StRefMultCorr("grefmult_P16id");
 //refmultCorrUtil->setVzForWeight(6, -6.0, 6.0);
 //refmultCorrUtil->readScaleForWeight("StRoot/StRefMultCorr/macros/weight_grefmult_vpd30_vpd5_Run14_P16id.txt");
 
 
 return kStOK ; 
}



Bool_t MyAnalysisMaker::IsBadEvent(StPicoEvent *picoEvent)
{
  
  if( !picoEvent ){
    LOG_WARN << " No PicoEvent! Skip! " << endm;
    return kStWarn;
  }

  //cout << "IsBadEvent: got vertex "<<endl;
  TVector3 pVertex = picoEvent->primaryVertex();
  
  vx = pVertex.x();
  vy = pVertex.y();
  vz = pVertex.z();

  //VertexZPos = vz;
  VpdVzPos    = picoEvent->vzVpd();
  if( (vx < 1.e-5 && vx > -1.e-5) &&       
      (vy < 1.e-5 && vy > -1.e-5) &&
      (vz < 1.e-5 && vz > -1.e-5)  )  
    return kTRUE; 
  

  //Trigger selection [Change your trigger id as per requirement]
   if(!(
	   (picoEvent->isTrigger(350003)) ||
	   (picoEvent->isTrigger(350013)) ||
	   (picoEvent->isTrigger(350023)) ||
	   (picoEvent->isTrigger(350033)) ||
	   (picoEvent->isTrigger(350043))

	   )) return kTRUE;
   
   
   //Z-vertex selection [change as per your requirement]
   if(fabs(vz)>30.0) 
     return kTRUE; 
   
   //Radial vertex selection [change as per your requirement]s
   if(sqrt(vx*vx+vy*vy)>2.0)
     return kTRUE;

   
  return kFALSE;
}

Int_t MyAnalysisMaker::Make()
{
  
  if(!mPicoDstMaker)
    {
      LOG_WARN << " No PicoDstMaker! Skip! " << endm;
      return kStWarn;
    }
  mPicoDst = mPicoDstMaker->picoDst();
  if(!mPicoDst) {
    LOG_WARN << " No PicoDst! Skip! " << endm;
    return kStWarn;
  }
  
  picoEvent = (StPicoEvent*)mPicoDst->event();
  if( !picoEvent ){
    LOG_WARN << " No PicoEvent! Skip! " << endm;
    return kStWarn;
  }
  
  
  EventCount-> Fill(0.2);


  //Nominal Event cuts and trigger cut
  if(IsBadEvent(picoEvent)) 
    return           kStOK;
  
  //pile up cut [if you want to apply pile up cut, change here]
  //float y1 = 2.9*picoEvent->refMult() + 270;
  //float y2 = 3.41*picoEvent->refMult() - 145;
  //nTofMatch > 1&nTofMatch >= 0.48 ∗ (refMult − 20); Shyam
  //if(picoEvent->btofTrayMultiplicity() > y1 || picoEvent->btofTrayMultiplicity() < y2) return kStOK;
    
  h2Refm_Tofm->Fill(picoEvent->refMult(),picoEvent->nBTOFMatch());
  
  EventCount-> Fill(1.2);
  
  Float_t         Vx_pos;
  Float_t         Vy_pos;
  
  
  VertexZPos  =  vz;
  Vx_pos      =  vx;
  Vy_pos      =  vy;

  //Filling vertex histograms
  VertexXY   ->                   Fill(vx, vy);
  VertexZ    ->                      Fill(VertexZPos);
  Vpd_vZ     ->                        Fill(VpdVzPos);

  
  CurrentEvent_vz = VertexZPos;
  //-----------------------------------------------------
  
  EventCount->Fill(2.2);

  Int_t RunId = picoEvent->runId();
  int RunYear = floor( RunId/pow(10,6) ); 
  int RunDay = floor( (RunId - RunYear*pow(10,6))/pow(10,3) );  
  day_num = RunDay;
  
  unsigned short refMult =             picoEvent->refMult();                               
  
  runnumber = picoEvent->runId();   
  reweight  =              1.0;
  
  //
  //[if you want to apply bad run rejection]
  //for(int irun=0; irun<87; irun++)
  //  {
  //    if(runnumber == badrun_1827[irun]) return kStOk;
  //  }


  //--------calling Hiroshi's RefmultCorr class for centrality selection ---------------                     
  zdc_cons  = picoEvent->ZDCx();
  bbc_cons  = picoEvent->BBCx();
  refmultCorrUtil    ->               init(runnumber);
  refmultCorrUtil->initEvent(refMult, VertexZPos, zdc_cons); 
  if(refmultCorrUtil->isBadRun(runnumber))                   
    { cout<<"!!!! Bad run found, skipped this Event...!!!"<<endl; 
      return kStOK;
    }
  cent = refmultCorrUtil->getCentralityBin9() ;
  CurrentEvent_centrality=cent +1;
  
  reweight = refmultCorrUtil->getWeight();
  
  //---------------------------------------------------------
  
  
  RefMult   ->Fill(refMult);
  EventCount->    Fill(3.2);
  CentCount -> Fill(cent+1);

  if(fabs(VertexZPos)<30) CentCount_Vz-> Fill(cent+1);
  
  EventCount->Fill(4.2);
  
  double pt          =         -999;
  int ntrack = 0;
  
  
  
  //if (CurrentEvent_centrality < 0 || CurrentEvent_centrality >8) return kStOK;
    
  
  //--------------- This is the track loop for storing single tracks applying track cuts below  -------------------------
  
  for (Int_t itr=0; itr<mPicoDst->numberOfTracks(); itr++)
    {
      const StPicoTrack *ptrack = (StPicoTrack*)mPicoDst->track(itr);
      if(!ptrack)  continue;
      if(!ptrack->isPrimary()) continue;
      
      float pt     =  ptrack->gMom().Pt(); 
      if(pt ==   0)               continue;     
      if(pt <  0.15)               continue;
      if(pt > 10.0)               continue;
      
      float      p  =  ptrack->gMom().Mag();
      
      int q =  ptrack->charge();
      if(q != +1 && q != -1)      continue;
      
      float dca =  ptrack->gDCA(Vx_pos, Vy_pos, VertexZPos);
      if(fabs(dca) >=3.0)         continue;
      
      float    eta  =     ptrack->gMom().Eta(); 
      if(fabs(eta) >1.0)         continue; 
      
      int nHitsFit  =    ptrack->nHitsFit();
      float ratio   =    (float) nHitsFit / (float) ptrack->nHitsMax();
      if(ratio  < 0.55)           continue;      
      if(ratio >= 1.05)           continue;
      if(nHitsFit<= 15)           continue;
      
      double   phi  =    ptrack->gMom().Phi(); 
      if(phi<0.0)             phi += twoPi;


      //TPC dedX information
      float dedx = ptrack->dEdx(); 
      
      
      //TOF Information
      double pp      =    ptrack->gMom().Mag();
      const Int_t bTofPidTraitsIndex = ptrack->bTofPidTraitsIndex();
      Float_t Beta = 0.0;
      double m1 =             -999;
      if(bTofPidTraitsIndex>=0)
	{
	  StPicoBTofPidTraits *btofPidTraits = mPicoDst->btofPidTraits(bTofPidTraitsIndex);
	  Beta = btofPidTraits->btofBeta();
	  if(Beta==0.0) m1 =9999.;
	  else m1 = pp*pp*(1.0/Beta/Beta - 1.0);
	  
	}
      
      

      //TPC Nsigma information
      float nsigma_pion = ptrack->nSigmaPion();
      float nsigma_kaon = ptrack->nSigmaKaon();
      float nsigma_proton = ptrack->nSigmaProton();
      int trackId =ptrack->id();
      dEdxvsp->Fill(p*q, dedx);//fill dedx
      if (Beta >0) hMass2->Fill(p,m1);
      

      
      //Will store track information here for invariant mass reconstruction
      TVector3 track_mom3(0.0, 0.0, 0.0);
      //track_mom3.SetXYZ(track->p().x(), track->p().y(), track->p().z());
      track_mom3.SetXYZ(ptrack->gMom().x(), ptrack->gMom().y(), ptrack->gMom().z());
      float p_mag = ptrack->gMom().Mag();
      float m2 = m1;
      
      trackk__ trackk;
      trackk.s_qq = q;
      trackk.s_mom = track_mom3;
     
      trackk.s_dca = fabs(dca);//dca;
      trackk.s_nsigma_pion = nsigma_pion;
      trackk.s_nsigma_kaon = nsigma_kaon;
      trackk.s_nhitsfit = nHitsFit;
      trackk.s_hitsratio = ratio;
            
      Bool_t IsPionTPC = kFALSE;
      Bool_t IsKaonTPC = kFALSE;
      if(-2.0 <= nsigma_pion && nsigma_pion <= 2.0) IsPionTPC = kTRUE;
      if(-2.0 <= nsigma_kaon && nsigma_kaon <= 2.0) IsKaonTPC = kTRUE;
      
      Bool_t IsPion = kFALSE;
      Bool_t IsKaon = kFALSE;
      if(Beta > 0)
	{
	  if(m1 >-0.2 && m1 < 0.15) IsPion = kTRUE;
	  if(m1 > 0.16 && m1 < 0.36) IsKaon = kTRUE;
	  if(IsKaon) hMass2_cut_kaon->Fill(pt,m1);
	}
      else
	{
	  if(-2.0 <= nsigma_pion && nsigma_pion <= 2.0) IsPion = kTRUE;
	  if(-2.0 <= nsigma_kaon && nsigma_kaon <= 2.0) IsKaon = kTRUE;
	  if(IsKaonTPC) dEdxvspkaon->Fill(p*q, dedx);
	}
      
      
      
      if(IsKaon) 
	{
	  if(q>0)
	    {
	      mPosKaon.push_back(trackk);
	    }
	  else if(q<0)
	    {
	      mNegKaon.push_back(trackk);
	    }
	}
      
      
    }//2nd particle loop end for v2
  


  
  
 MakeRealPair_Rsn();      // same event
 //cout << "DONE real pair "<< mEventsProcessed<<endl;
 MakeRealRotPair_Rsn();   // rotation event
 //cout << "DONE rotated pair "<< mEventsProcessed<<endl;
 clearPIDTracks_Rsn();
 
 mEventsProcessed++   ;
 EventCount->Fill(9.2);
 
  return         kStOK ;
  
}//--------------- Make (Event) loop ends--------------------------


Int_t MyAnalysisMaker::Finish()
{ 
  cout<<" Inside Finish writing histograms..."<<endl;

  
  histogram_output    ->   cd();  // Write Shift Histograms in file
  VertexZ             ->Write();
  VertexXY            ->Write();
  RefMult             ->Write();
  EventCount          ->Write();
  CentCount           ->Write();
  CentCount_Vz           ->Write();
  h2Refm_Tofm->Write();
  
  dEdxvspkaon->Write();
  hMass2_cut_kaon->Write();
  
  syst_phimeson_NumTPC->Write();
  syst_phimeson_RotTPC->Write();  
 
  cout<<" DONE writing histograms..."<<endl;
  
  //-------------end---------------//
  histogram_output    ->Close();

  cout <<"\n ======> All done <======"<<endl;
  cout<<" Acutal #Events Processed = " <<mEventsProcessed<<"\n###### Thank You ######\n"<< endl ;
  return kStOk ;  

}



//new add
void MyAnalysisMaker::MakeRealPair_Rsn(){

  //cout << "Just in MakeReal Pair: "<< mPosKaon.size()<< "  "<<mNegKaon.size()  <<endl;

  TLorentzVector t_pionPos(0,0,0,0);
  TLorentzVector t_pionNeg(0,0,0,0);

  TLorentzVector t_kaonPos(0,0,0,0);
  TLorentzVector t_kaonNeg(0,0,0,0);
  
  TLorentzVector t_protonPos(0,0,0,0);
  TLorentzVector t_protonNeg(0,0,0,0);
  
  TLorentzVector t_phi(0,0,0,0);
  

  reweight = 1.0;

  //CurrentEvent_Psi_EPD;
  //CurrentEvent_Psi_BBC;
  //------------------------------------------------------------------------------------------------------
  // For Phi Signal
  for(unsigned int i=0;i<mPosKaon.size();i++)
    {
      for(unsigned int j=0;j<mNegKaon.size();j++)
	{
	  t_kaonPos.SetXYZM(mPosKaon[i].s_mom.X(), mPosKaon[i].s_mom.Y(), mPosKaon[i].s_mom.Z(),  kMass);
	  t_kaonNeg.SetXYZM(mNegKaon[j].s_mom.X(), mNegKaon[j].s_mom.Y(), mNegKaon[j].s_mom.Z(),  kMass);
	  
	  // phi=(k+)+(k-)      
	  t_phi = t_kaonPos + t_kaonNeg;
	  float rapidity_phimeson = t_phi.Rapidity();
	 

	  bool isdipangle_cut_phimeson = false;
	  double dipangle_phimeson = dDipAngle(t_kaonPos, t_kaonNeg);
	  if(dipangle_phimeson>0.04) isdipangle_cut_phimeson=true;
	  
	  if( fabs(rapidity_phimeson) < fRapcut_pair && isdipangle_cut_phimeson)
	    {
	      float invm_phimeson = t_phi.M();
	      float pt_phimeson = t_phi.Pt();
	      float eta_phimeson = t_phi.PseudoRapidity(); 
	      float phi_phimeson = t_phi.Phi();
	      if(phi_phimeson<0.) phi_phimeson += twoPi;
	      
	      syst_phimeson_NumTPC->Fill(invm_phimeson, pt_phimeson, CurrentEvent_centrality);
	     
	      
	      
	    }//rap cut
	}
    }
  t_kaonPos.SetXYZM(0, 0, 0, 0);
  t_kaonNeg.SetXYZM(0, 0, 0, 0);

 
}



void MyAnalysisMaker::MakeRealRotPair_Rsn(){

  TLorentzVector t_pionPos(0,0,0,0);
  TLorentzVector t_pionNeg(0,0,0,0);

  TLorentzVector t_kaonPos(0,0,0,0);
  TLorentzVector t_kaonNeg(0,0,0,0);
  
  TLorentzVector t_protonPos(0,0,0,0);
  TLorentzVector t_protonNeg(0,0,0,0);
  
  TLorentzVector t_phi(0,0,0,0);
 
  TVector2 Q_eta_full(0,0);
  TVector2 Q_eta_full_i(0,0);
  
  reweight = 1.0;
  
  //------------------------------------------------------------------------------------------------------
  // For Phi Signal
  for(unsigned int i=0;i<mPosKaon.size();i++)
    {
      for(unsigned int j=0;j<mNegKaon.size();j++)
	{
	  t_kaonPos.SetXYZM(mPosKaon[i].s_mom.X(), mPosKaon[i].s_mom.Y(), mPosKaon[i].s_mom.Z(),  kMass);
	  t_kaonNeg.SetXYZM(-1.0*mNegKaon[j].s_mom.X(), -1.0*mNegKaon[j].s_mom.Y(), mNegKaon[j].s_mom.Z(),  kMass);

	  // phi=(k+)+(k-)      
	  t_phi = t_kaonPos + t_kaonNeg;
	  float rapidity_phimeson = t_phi.Rapidity();
	  
	  
	  bool isdipangle_cut_phimeson = false;
	  double dipangle_phimeson = dDipAngle(t_kaonPos, t_kaonNeg);
	  if(dipangle_phimeson>0.04) isdipangle_cut_phimeson=true;
	  
	   if( fabs(rapidity_phimeson) < fRapcut_pair && isdipangle_cut_phimeson)
	    {
	      float invm_phimeson = t_phi.M();
	      float pt_phimeson = t_phi.Pt();
	      float eta_phimeson = t_phi.PseudoRapidity(); 
	      float phi_phimeson = t_phi.Phi();
	      if(phi_phimeson<0.) phi_phimeson += twoPi;
	      
	   
	      syst_phimeson_RotTPC->Fill(invm_phimeson, pt_phimeson, CurrentEvent_centrality);


	       
	    }//rap
	}
    }
  t_kaonPos.SetXYZM(0, 0, 0, 0);
  t_kaonNeg.SetXYZM(0, 0, 0, 0);

  //------------------------------------------------------------------------------------------------------
  //------------------------------------------------------------------------------------------------------
  // Implent other strong decay particles
  //------------------------------------------------------------------------------------------------------


}


void MyAnalysisMaker :: clearPIDTracks_Rsn(){
  mPosProton.clear();
  mNegProton.clear();
  mPosPion.clear();
  mNegPion.clear();
  mPosKaon.clear();
  mNegKaon.clear();
}


/////////
double MyAnalysisMaker::dDipAngle(TLorentzVector a,TLorentzVector b)
{
  double p,adotb;
  adotb = sqrt(a.X()*a.X()+a.Y()*a.Y())*sqrt(b.X()*b.X()+b.Y()*b.Y()) + a.Z()*b.Z();
  p = 	sqrt(a.X()*a.X()+a.Y()*a.Y()+a.Z()*a.Z())*sqrt(b.X()*b.X()+b.Y()*b.Y()+b.Z()*b.Z());
  double theta = acos(adotb/p);
  return (theta); 
}

double MyAnalysisMaker::OpenAngle(TLorentzVector p1, TLorentzVector p2, double res_mass)
{
  TVector3 p1Vect = p1.Vect();
  TVector3 p2Vect = p2.Vect();
  double magP1P2 = TMath::Sqrt(p1Vect.Mag2()*p2Vect.Mag2());

  double cosA = (p1.E()*p2.E() - 0.5*(res_mass*res_mass - p1.M()*p1.M() - p2.M()*p2.M()))/magP1P2;
  return (cosA); 
  
}

